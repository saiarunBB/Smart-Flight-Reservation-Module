package com.flight.reservation;

import com.flight.reservation.module1.*;
import com.flight.reservation.module3.*;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class FlightReservationTests {

    @Autowired PassengerService passengerService;
    @Autowired TransactionService transactionService;
    @Autowired PNRGenerator pnrGenerator;

    @Test
    void contextLoads() {}

    @Test
    void pnrGeneratorProducesUniqueValidCodes() {
        String a = pnrGenerator.generate();
        String b = pnrGenerator.generate();
        assertNotEquals(a, b);
        assertTrue(a.matches("[A-Z0-9]{6}"));
        assertTrue(pnrGenerator.isValid(a));
    }

    @Test
    void passengerRegistrationAndLogin() {
        Passenger p = passengerService.register(
                "Test User", "testuniq@mail.com", "9000000000", "pass123");
        assertNotNull(p.getPassengerId());
        assertEquals("Test User", p.getFullName());
        assertTrue(passengerService.authenticate("testuniq@mail.com", "pass123"));
        assertFalse(passengerService.authenticate("testuniq@mail.com", "wrongpass"));
    }

    @Test
    void bookingCreatesConfirmedReservation() {
        // Uses seeded data: passenger_id=1, seat_id=2 (12A on flight 1)
        Reservation res = transactionService.processBooking(1, 2);
        assertNotNull(res);
        assertEquals(Reservation.ResStatus.CONFIRMED, res.getResStatus());
        assertNotNull(res.getPnrCode());
        assertTrue(res.getPnrCode().matches("[A-Z0-9]{6}"));
    }

    @Test
    void doubleBookingSameSeatFails() {
        // seat_id=3 (12B) — first booking should succeed, second should throw
        transactionService.processBooking(2, 3);
        assertThrows(Exception.class, () -> transactionService.processBooking(3, 3));
    }
}