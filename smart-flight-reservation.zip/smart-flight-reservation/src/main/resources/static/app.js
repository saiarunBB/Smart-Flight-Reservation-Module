const API = '';

function showTab(name) {
  document.querySelectorAll('main section').forEach(s => s.style.display = 'none');
  document.getElementById('tab-' + name).style.display = 'flex';
}

function fmt(data) { return JSON.stringify(data, null, 2); }

function setResult(id, data, isError) {
  const el = document.getElementById(id);
  el.textContent = fmt(data);
  el.className = 'result ' + (isError ? 'error' : 'ok');
}

async function post(url, body) {
  const r = await fetch(API + url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  return { ok: r.ok, data: await r.json() };
}

async function get(url) {
  const r = await fetch(API + url);
  return { ok: r.ok, data: await r.json() };
}

async function put(url) {
  const r = await fetch(API + url, { method: 'PUT' });
  return { ok: r.ok, data: await r.json() };
}

// MODULE 1
async function registerPassenger() {
  const { ok, data } = await post('/api/passengers/register', {
    fullName: document.getElementById('reg-name').value,
    email:    document.getElementById('reg-email').value,
    phone:    document.getElementById('reg-phone').value,
    password: document.getElementById('reg-pass').value
  });
  setResult('reg-result', data, !ok);
}

async function loginPassenger() {
  const { ok, data } = await post('/api/passengers/login', {
    email:    document.getElementById('login-email').value,
    password: document.getElementById('login-pass').value
  });
  setResult('login-result', data, !ok);
}

async function loadPassengers() {
  const { ok, data } = await get('/api/passengers');
  setResult('passengers-list', data, !ok);
}

// MODULE 2
async function searchFlights() {
  const origin = document.getElementById('search-origin').value;
  const dest   = document.getElementById('search-dest').value;
  const { ok, data } = await get(`/api/flights/search?origin=${origin}&destination=${dest}`);
  setResult('flight-results', data, !ok);
}

async function loadSeats() {
  const id = document.getElementById('seat-flight-id').value;
  const { ok, data } = await get(`/api/flights/${id}/seats`);
  setResult('seat-results', data, !ok);
}

async function loadAllFlights() {
  const { ok, data } = await get('/api/flights');
  setResult('all-flights', data, !ok);
}

// MODULE 3
async function bookSeat() {
  const { ok, data } = await post('/api/reservations/book', {
    passengerId: parseInt(document.getElementById('book-pid').value),
    seatId:      parseInt(document.getElementById('book-seatid').value)
  });
  setResult('book-result', data, !ok);
}

async function findByPnr() {
  const pnr = document.getElementById('pnr-input').value.toUpperCase();
  const { ok, data } = await get(`/api/reservations/pnr/${pnr}`);
  setResult('pnr-result', data, !ok);
}

async function cancelReservation() {
  const id = document.getElementById('cancel-id').value;
  const { ok, data } = await put(`/api/reservations/${id}/cancel`);
  setResult('cancel-result', data, !ok);
}

async function loadReservations() {
  const { ok, data } = await get('/api/reservations');
  setResult('res-list', data, !ok);
}

// MODULE 4
async function loadReport() {
  const { ok, data } = await get('/api/admin/report');
  setResult('report-result', data, !ok);
}

async function loadLogs() {
  const { ok, data } = await get('/api/admin/logs');
  setResult('log-result', data, !ok);
}

async function addLog() {
  const { ok, data } = await post('/api/admin/log', {
    eventType: document.getElementById('log-type').value,
    entityId:  document.getElementById('log-entity').value,
    message:   document.getElementById('log-message').value
  });
  setResult('add-log-result', data, !ok);
}

// MODULE 5
async function doCheckIn() {
  const id = document.getElementById('ci-resid').value;
  const { ok, data } = await post(`/api/checkin/${id}`, {});
  setResult('ci-result', data, !ok);
}

async function issueBoardingPass() {
  const id = document.getElementById('bp-resid').value;
  const { ok, data } = await post(`/api/checkin/${id}/boarding-pass`, {});
  setResult('bp-result', data, !ok);
}

async function addAncillary() {
  const id = document.getElementById('anc-resid').value;
  const { ok, data } = await post(`/api/checkin/${id}/ancillary`, {
    serviceType: document.getElementById('anc-type').value,
    description: document.getElementById('anc-desc').value,
    price:       document.getElementById('anc-price').value
  });
  setResult('anc-result', data, !ok);
}

async function loadCheckIns() {
  const { ok, data } = await get('/api/checkin/all');
  setResult('all-ci', data, !ok);
}