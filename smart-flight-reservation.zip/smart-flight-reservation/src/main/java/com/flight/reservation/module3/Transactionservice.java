package com.flight.reservation.module3;

import com.flight.reservation.module1.Passenger;
import com.flight.reservation.module1.PassengerService;
import com.flight.reservation.module2.Seat;
import com.flight.reservation.module2.SeatRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.UUID;

@Service
public class TransactionService {

    private static final double LAMBDA = 0.5;

    private final ReservationRepository reservationRepo;
    private final PaymentRepository     paymentRepo;
    private final SeatRepository        seatRepo;
    private final PassengerService      passengerService;
    private final PNRGenerator          pnrGenerator;

    public TransactionService(ReservationRepository reservationRepo,
                               PaymentRepository paymentRepo,
                               SeatRepository seatRepo,
                               PassengerService passengerService,
                               PNRGenerator pnrGenerator) {
        this.reservationRepo = reservationRepo;
        this.paymentRepo     = paymentRepo;
        this.seatRepo        = seatRepo;
        this.passengerService = passengerService;
        this.pnrGenerator    = pnrGenerator;
    }

    public double computeDynamicFare(double basePrice, int nBooked, int nTotal) {
        double load = (nTotal == 0) ? 0 : (double) nBooked / nTotal;
        return basePrice * Math.exp(LAMBDA * load);
    }

    @Transactional
    public Reservation processBooking(int passengerId, int seatId) {
        Passenger passenger = passengerService.findById(passengerId);

        // Pessimistic lock on seat — prevents double booking
        Seat seat = seatRepo.findByIdWithLock(seatId)
                .orElseThrow(() -> new IllegalArgumentException("Seat not found: " + seatId));

        if (Boolean.TRUE.equals(seat.getIsBooked()))
            throw new IllegalStateException("Seat " + seat.getSeatCode() + " is already booked.");

        int nTotal  = seatRepo.countByFlightId(seat.getFlightId());
        int nBooked = seatRepo.countByFlightIdAndIsBooked(seat.getFlightId(), true);

        double fare = computeDynamicFare(seat.getBasePrice(), nBooked, nTotal);
        fare = fare * (1.0 - passenger.getTier().getDiscount());

        // Create reservation
        Reservation res = new Reservation();
        res.setPassengerId(passengerId);
        res.setFlightId(seat.getFlightId());
        res.setSeatId(seatId);
        res.setAmountPaid(Math.round(fare * 100.0) / 100.0);
        res = reservationRepo.save(res);

        // Payment record
        Payment payment = new Payment();
        payment.setReservationId(res.getReservationId());
        payment.setTxnRef("TXN-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        payment.setAmountPaid(res.getAmountPaid());
        payment.setPaymentStatus(Payment.PaymentStatus.SUCCESS);
        paymentRepo.save(payment);

        // Atomically mark seat booked
        seat.setIsBooked(true);
        seatRepo.save(seat);

        // Generate PNR and confirm
        res.setPnrCode(pnrGenerator.generate());
        res.setResStatus(Reservation.ResStatus.CONFIRMED);
        return reservationRepo.save(res);
    }

    public Reservation cancelReservation(int reservationId) {
        Reservation res = reservationRepo.findById(reservationId)
                .orElseThrow(() -> new IllegalArgumentException("Reservation not found"));
        if (res.getResStatus() == Reservation.ResStatus.CANCELLED)
            throw new IllegalStateException("Already cancelled.");

        // Release seat
        if (res.getSeatId() != null) {
            seatRepo.findById(res.getSeatId()).ifPresent(s -> {
                s.setIsBooked(false);
                seatRepo.save(s);
            });
        }
        res.setResStatus(Reservation.ResStatus.CANCELLED);
        return reservationRepo.save(res);
    }

    public Reservation findByPnr(String pnr) {
        return reservationRepo.findByPnrCode(pnr)
                .orElseThrow(() -> new IllegalArgumentException("PNR not found: " + pnr));
    }

    public List<Reservation> listAll() {
        return reservationRepo.findAll();
    }

    public List<Reservation> listByPassenger(int passengerId) {
        return reservationRepo.findByPassengerId(passengerId);
    }

    public List<Payment> listAllPayments() {
        return paymentRepo.findAll();
    }
}