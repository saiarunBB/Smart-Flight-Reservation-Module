package com.flight.reservation.module5;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "CHECK_INS")
public class CheckIn {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "checkin_id")
    private Integer checkinId;

    @Column(name = "reservation_id", nullable = false)
    private Integer reservationId;

    @Column(name = "checkin_time")
    private LocalDateTime checkinTime = LocalDateTime.now();

    @Column(name = "seat_confirmed")
    private String seatConfirmed;

    @Column(name = "status")
    private String status = "CHECKED_IN";

    public CheckIn() {}

    public Integer getCheckinId()          { return checkinId; }
    public Integer getReservationId()      { return reservationId; }
    public LocalDateTime getCheckinTime()  { return checkinTime; }
    public String  getSeatConfirmed()      { return seatConfirmed; }
    public String  getStatus()             { return status; }

    public void setReservationId(Integer v) { this.reservationId = v; }
    public void setSeatConfirmed(String v)  { this.seatConfirmed = v; }
    public void setStatus(String v)         { this.status        = v; }
}