package com.flight.reservation.controller;

import com.flight.reservation.module3.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/reservations")
public class ReservationController {

    private final TransactionService service;

    public ReservationController(TransactionService service) { this.service = service; }

    @PostMapping("/book")
    public ResponseEntity<?> book(@RequestBody Map<String, Integer> body) {
        try {
            Reservation res = service.processBooking(body.get("passengerId"), body.get("seatId"));
            return ResponseEntity.ok(res);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @GetMapping
    public List<Reservation> listAll() { return service.listAll(); }

    @GetMapping("/pnr/{pnr}")
    public ResponseEntity<?> findByPnr(@PathVariable String pnr) {
        try { return ResponseEntity.ok(service.findByPnr(pnr)); }
        catch (Exception e) { return ResponseEntity.notFound().build(); }
    }

    @GetMapping("/passenger/{pid}")
    public List<Reservation> byPassenger(@PathVariable int pid) {
        return service.listByPassenger(pid);
    }

    @PutMapping("/{id}/cancel")
    public ResponseEntity<?> cancel(@PathVariable int id) {
        try { return ResponseEntity.ok(service.cancelReservation(id)); }
        catch (Exception e) { return ResponseEntity.badRequest().body(Map.of("error", e.getMessage())); }
    }

    @GetMapping("/payments")
    public List<Payment> payments() { return service.listAllPayments(); }
}