package com.flight.reservation.module2;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface FlightRepository extends JpaRepository<Flight, Integer> {
    List<Flight> findByOriginIgnoreCaseAndDestinationIgnoreCase(String origin, String destination);
}