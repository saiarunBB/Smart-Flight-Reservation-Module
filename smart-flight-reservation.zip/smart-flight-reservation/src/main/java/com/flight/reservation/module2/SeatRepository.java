package com.flight.reservation.module2;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import jakarta.persistence.LockModeType;
import java.util.List;
import java.util.Optional;

public interface SeatRepository extends JpaRepository<Seat, Integer> {
    List<Seat> findByFlightIdAndIsBooked(Integer flightId, Boolean isBooked);
    List<Seat> findByFlightId(Integer flightId);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT s FROM Seat s WHERE s.seatId = :id")
    Optional<Seat> findByIdWithLock(Integer id);

    int countByFlightId(Integer flightId);
    int countByFlightIdAndIsBooked(Integer flightId, Boolean isBooked);
}