package com.flight.reservation.module4;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "AUDIT_LOG")
public class AuditLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "log_id")
    private Integer logId;

    @Column(name = "event_type")
    private String eventType;

    @Column(name = "entity_id")
    private Integer entityId;

    @Column(name = "message", length = 500)
    private String message;

    @Column(name = "logged_at")
    private LocalDateTime loggedAt = LocalDateTime.now();

    public AuditLog() {}

    public AuditLog(String eventType, Integer entityId, String message) {
        this.eventType = eventType;
        this.entityId  = entityId;
        this.message   = message;
    }

    public Integer getLogId()           { return logId; }
    public String  getEventType()       { return eventType; }
    public Integer getEntityId()        { return entityId; }
    public String  getMessage()         { return message; }
    public LocalDateTime getLoggedAt()  { return loggedAt; }
}