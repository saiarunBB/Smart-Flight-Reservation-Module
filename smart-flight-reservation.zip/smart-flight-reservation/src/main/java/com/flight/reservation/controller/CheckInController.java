package com.flight.reservation.controller;

import com.flight.reservation.module5.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/checkin")
public class CheckInController {

    private final CheckInService service;

    public CheckInController(CheckInService service) { this.service = service; }

    @PostMapping("/{reservationId}")
    public ResponseEntity<?> checkIn(@PathVariable int reservationId) {
        try { return ResponseEntity.ok(service.performCheckIn(reservationId)); }
        catch (Exception e) { return ResponseEntity.badRequest().body(Map.of("error", e.getMessage())); }
    }

    @PostMapping("/{reservationId}/boarding-pass")
    public ResponseEntity<?> issueBoardingPass(@PathVariable int reservationId) {
        try { return ResponseEntity.ok(service.issueBoardingPass(reservationId)); }
        catch (Exception e) { return ResponseEntity.badRequest().body(Map.of("error", e.getMessage())); }
    }

    @PostMapping("/{reservationId}/ancillary")
    public ResponseEntity<?> addAncillary(@PathVariable int reservationId,
                                           @RequestBody Map<String, String> body) {
        try {
            AncillaryService svc = service.addAncillary(
                    reservationId,
                    body.get("serviceType"),
                    body.get("description"),
                    Double.parseDouble(body.getOrDefault("price", "0")));
            return ResponseEntity.ok(svc);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @GetMapping("/{reservationId}/ancillary")
    public List<AncillaryService> getAncillaries(@PathVariable int reservationId) {
        return service.getAncillaries(reservationId);
    }

    @GetMapping("/all")
    public List<CheckIn> allCheckIns() { return service.allCheckIns(); }

    @GetMapping("/boarding-passes")
    public List<BoardingPass> allBoardingPasses() { return service.allBoardingPasses(); }
}