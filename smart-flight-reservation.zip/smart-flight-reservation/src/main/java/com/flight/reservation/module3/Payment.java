package com.flight.reservation.module3;

import jakarta.persistence.*;

@Entity
@Table(name = "PAYMENTS")
public class Payment {

    public enum PaymentStatus { PENDING, SUCCESS, FAILED }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "payment_id")
    private Integer paymentId;

    @Column(name = "reservation_id", nullable = false)
    private Integer reservationId;

    @Column(name = "txn_ref", nullable = false, unique = true)
    private String txnRef;

    @Column(name = "amount_paid", nullable = false)
    private Double amountPaid;

    @Enumerated(EnumType.STRING)
    @Column(name = "payment_status")
    private PaymentStatus paymentStatus = PaymentStatus.PENDING;

    public Payment() {}

    public Integer getPaymentId()          { return paymentId; }
    public Integer getReservationId()      { return reservationId; }
    public String  getTxnRef()             { return txnRef; }
    public Double  getAmountPaid()         { return amountPaid; }
    public PaymentStatus getPaymentStatus() { return paymentStatus; }

    public void setReservationId(Integer v)     { this.reservationId = v; }
    public void setTxnRef(String v)             { this.txnRef        = v; }
    public void setAmountPaid(Double v)         { this.amountPaid    = v; }
    public void setPaymentStatus(PaymentStatus v) { this.paymentStatus = v; }
}