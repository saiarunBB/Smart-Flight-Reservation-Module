package com.flight.reservation.module3;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "RESERVATIONS")
public class Reservation {

    public enum ResStatus { PENDING, CONFIRMED, CANCELLED }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "reservation_id")
    private Integer reservationId;

    @Column(name = "passenger_id", nullable = false)
    private Integer passengerId;

    @Column(name = "flight_id", nullable = false)
    private Integer flightId;

    @Column(name = "seat_id")
    private Integer seatId;

    @Column(name = "pnr_code", unique = true, length = 6)
    private String pnrCode;

    @Enumerated(EnumType.STRING)
    @Column(name = "res_status")
    private ResStatus resStatus = ResStatus.PENDING;

    @Column(name = "date_created")
    private LocalDateTime dateCreated = LocalDateTime.now();

    @Column(name = "amount_paid")
    private Double amountPaid;

    public Reservation() {}

    public Integer getReservationId() { return reservationId; }
    public Integer getPassengerId()   { return passengerId; }
    public Integer getFlightId()      { return flightId; }
    public Integer getSeatId()        { return seatId; }
    public String  getPnrCode()       { return pnrCode; }
    public ResStatus getResStatus()   { return resStatus; }
    public LocalDateTime getDateCreated() { return dateCreated; }
    public Double  getAmountPaid()    { return amountPaid; }

    public void setPassengerId(Integer v) { this.passengerId = v; }
    public void setFlightId(Integer v)    { this.flightId    = v; }
    public void setSeatId(Integer v)      { this.seatId      = v; }
    public void setPnrCode(String v)      { this.pnrCode     = v; }
    public void setResStatus(ResStatus v) { this.resStatus   = v; }
    public void setAmountPaid(Double v)   { this.amountPaid  = v; }
}