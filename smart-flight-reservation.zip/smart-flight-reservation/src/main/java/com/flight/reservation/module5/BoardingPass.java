package com.flight.reservation.module5;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "BOARDING_PASSES")
public class BoardingPass {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "bp_id")
    private Integer bpId;

    @Column(name = "reservation_id", nullable = false)
    private Integer reservationId;

    @Column(name = "boarding_group")
    private String boardingGroup;

    @Column(name = "gate")
    private String gate;

    @Column(name = "issued_at")
    private LocalDateTime issuedAt = LocalDateTime.now();

    public BoardingPass() {}

    public Integer getBpId()              { return bpId; }
    public Integer getReservationId()     { return reservationId; }
    public String  getBoardingGroup()     { return boardingGroup; }
    public String  getGate()             { return gate; }
    public LocalDateTime getIssuedAt()   { return issuedAt; }

    public void setReservationId(Integer v) { this.reservationId = v; }
    public void setBoardingGroup(String v)  { this.boardingGroup = v; }
    public void setGate(String v)           { this.gate          = v; }
}