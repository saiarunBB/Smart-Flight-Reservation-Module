package com.flight.reservation.controller;

import com.flight.reservation.module1.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/passengers")
public class PassengerController {

    private final PassengerService service;

    public PassengerController(PassengerService service) {
        this.service = service;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody Map<String, String> body) {
        try {
            Passenger p = service.register(
                    body.get("fullName"), body.get("email"),
                    body.get("phone"),   body.get("password"));
            return ResponseEntity.ok(p);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> body) {
        boolean ok = service.authenticate(body.get("email"), body.get("password"));
        if (ok) return ResponseEntity.ok(Map.of("status", "Login successful"));
        return ResponseEntity.status(401).body(Map.of("error", "Invalid credentials"));
    }

    @GetMapping
    public List<Passenger> listAll() { return service.listAll(); }

    @GetMapping("/{id}")
    public ResponseEntity<?> getById(@PathVariable int id) {
        try { return ResponseEntity.ok(service.findById(id)); }
        catch (Exception e) { return ResponseEntity.notFound().build(); }
    }

    @PutMapping("/{email}/tier")
    public ResponseEntity<?> updateTier(@PathVariable String email,
                                         @RequestParam String tier) {
        try {
            Passenger p = service.updateTier(email, FrequentFlyerTier.valueOf(tier.toUpperCase()));
            return ResponseEntity.ok(p);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }
}