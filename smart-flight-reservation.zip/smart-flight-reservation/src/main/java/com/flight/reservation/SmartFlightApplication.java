package com.flight.reservation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartFlightApp {
    public static void main(String[] args) {
        SpringApplication.run(SmartFlightApp.class, args);
    }
}