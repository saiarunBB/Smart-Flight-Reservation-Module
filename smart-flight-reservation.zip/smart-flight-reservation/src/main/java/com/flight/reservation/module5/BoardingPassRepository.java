package com.flight.reservation.module5;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface BoardingPassRepository extends JpaRepository<BoardingPass, Integer> {
    Optional<BoardingPass> findByReservationId(Integer reservationId);
}