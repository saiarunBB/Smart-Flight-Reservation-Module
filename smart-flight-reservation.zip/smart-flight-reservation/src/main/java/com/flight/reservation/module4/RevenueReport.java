package com.flight.reservation.module4;

public class RevenueReport {
    private int totalReservations;
    private int confirmedReservations;
    private int cancelledReservations;
    private double totalRevenue;
    private double averageFare;
    private int totalFlights;
    private int totalPassengers;

    public RevenueReport() {}

    public int    getTotalReservations()    { return totalReservations; }
    public int    getConfirmedReservations() { return confirmedReservations; }
    public int    getCancelledReservations() { return cancelledReservations; }
    public double getTotalRevenue()         { return totalRevenue; }
    public double getAverageFare()          { return averageFare; }
    public int    getTotalFlights()         { return totalFlights; }
    public int    getTotalPassengers()      { return totalPassengers; }

    public void setTotalReservations(int v)     { this.totalReservations    = v; }
    public void setConfirmedReservations(int v) { this.confirmedReservations = v; }
    public void setCancelledReservations(int v) { this.cancelledReservations = v; }
    public void setTotalRevenue(double v)       { this.totalRevenue          = v; }
    public void setAverageFare(double v)        { this.averageFare           = v; }
    public void setTotalFlights(int v)          { this.totalFlights          = v; }
    public void setTotalPassengers(int v)       { this.totalPassengers       = v; }
}