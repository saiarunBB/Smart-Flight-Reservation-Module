package com.flight.reservation.module2;

import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class FlightService {

    private final FlightRepository flightRepo;
    private final SeatRepository   seatRepo;

    public FlightService(FlightRepository flightRepo, SeatRepository seatRepo) {
        this.flightRepo = flightRepo;
        this.seatRepo   = seatRepo;
    }

    public List<Flight> searchFlights(String origin, String destination) {
        return flightRepo.findByOriginIgnoreCaseAndDestinationIgnoreCase(origin, destination);
    }

    public List<Flight> listAllFlights() {
        return flightRepo.findAll();
    }

    public Flight getFlightById(int id) {
        return flightRepo.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Flight not found: " + id));
    }

    public List<Seat> getAvailableSeats(int flightId) {
        return seatRepo.findByFlightIdAndIsBooked(flightId, false);
    }

    public List<Seat> getAllSeats(int flightId) {
        return seatRepo.findByFlightId(flightId);
    }

    public Seat getSeatById(int seatId) {
        return seatRepo.findById(seatId)
                .orElseThrow(() -> new IllegalArgumentException("Seat not found: " + seatId));
    }

    public int totalSeats(int flightId) {
        return seatRepo.countByFlightId(flightId);
    }

    public int bookedSeats(int flightId) {
        return seatRepo.countByFlightIdAndIsBooked(flightId, true);
    }
}