package com.flight.reservation.module3;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface ReservationRepository extends JpaRepository<Reservation, Integer> {
    Optional<Reservation> findByPnrCode(String pnrCode);
    List<Reservation> findByPassengerId(Integer passengerId);
    List<Reservation> findByFlightId(Integer flightId);
}