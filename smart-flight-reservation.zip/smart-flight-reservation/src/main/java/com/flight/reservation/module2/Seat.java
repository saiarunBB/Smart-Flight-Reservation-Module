package com.flight.reservation.module2;

import jakarta.persistence.*;

@Entity
@Table(name = "SEATS_INVENTORY",
       uniqueConstraints = @UniqueConstraint(columnNames = {"flight_id","seat_code"}))
public class Seat {

    public enum SeatClass { ECONOMY, BUSINESS, FIRST }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "seat_id")
    private Integer seatId;

    @Column(name = "flight_id", nullable = false)
    private Integer flightId;

    @Column(name = "seat_code", nullable = false)
    private String seatCode;

    @Enumerated(EnumType.STRING)
    @Column(name = "seat_class", nullable = false)
    private SeatClass seatClass;

    @Column(name = "base_price", nullable = false)
    private Double basePrice;

    @Column(name = "is_booked")
    private Boolean isBooked = false;

    public Seat() {}

    public Integer getSeatId()      { return seatId; }
    public Integer getFlightId()    { return flightId; }
    public String  getSeatCode()    { return seatCode; }
    public SeatClass getSeatClass() { return seatClass; }
    public Double  getBasePrice()   { return basePrice; }
    public Boolean getIsBooked()    { return isBooked; }

    public void setIsBooked(Boolean booked) { this.isBooked = booked; }
    public void setFlightId(Integer id)     { this.flightId  = id; }
    public void setSeatCode(String code)    { this.seatCode  = code; }
    public void setSeatClass(SeatClass sc)  { this.seatClass = sc; }
    public void setBasePrice(Double price)  { this.basePrice = price; }
}