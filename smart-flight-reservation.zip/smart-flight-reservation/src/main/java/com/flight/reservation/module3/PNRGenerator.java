package com.flight.reservation.module3;

import org.springframework.stereotype.Component;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class PNRGenerator {

    private static final String CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    private final Set<String> issued = ConcurrentHashMap.newKeySet();
    private final Random random = new Random();

    public String generate() {
        String pnr;
        do {
            StringBuilder sb = new StringBuilder(6);
            for (int i = 0; i < 6; i++)
                sb.append(CHARS.charAt(random.nextInt(CHARS.length())));
            pnr = sb.toString();
        } while (issued.contains(pnr));
        issued.add(pnr);
        return pnr;
    }

    public boolean isValid(String pnr) {
        return pnr != null && pnr.matches("[A-Z0-9]{6}") && issued.contains(pnr);
    }
}