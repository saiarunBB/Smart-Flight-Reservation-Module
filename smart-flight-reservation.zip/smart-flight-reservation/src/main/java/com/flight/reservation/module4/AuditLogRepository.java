package com.flight.reservation.module4;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface AuditLogRepository extends JpaRepository<AuditLog, Integer> {
    List<AuditLog> findByEventTypeOrderByLoggedAtDesc(String eventType);
}