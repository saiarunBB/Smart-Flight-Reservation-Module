package com.flight.reservation.module5;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface CheckInRepository extends JpaRepository<CheckIn, Integer> {
    Optional<CheckIn> findByReservationId(Integer reservationId);
    boolean existsByReservationId(Integer reservationId);
}