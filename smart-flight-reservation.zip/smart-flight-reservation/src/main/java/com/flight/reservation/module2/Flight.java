package com.flight.reservation.module2;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "FLIGHTS")
public class Flight {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "flight_id")
    private Integer flightId;

    @Column(name = "airline_code", nullable = false)
    private String airlineCode;

    @Column(nullable = false)
    private String origin;

    @Column(nullable = false)
    private String destination;

    @Column(name = "departure_time", nullable = false)
    private LocalDateTime departureTime;

    public Flight() {}

    public Integer getFlightId()             { return flightId; }
    public String  getAirlineCode()          { return airlineCode; }
    public String  getOrigin()               { return origin; }
    public String  getDestination()          { return destination; }
    public LocalDateTime getDepartureTime()  { return departureTime; }

    public void setAirlineCode(String v)          { this.airlineCode   = v; }
    public void setOrigin(String v)               { this.origin        = v; }
    public void setDestination(String v)          { this.destination   = v; }
    public void setDepartureTime(LocalDateTime v) { this.departureTime = v; }
}