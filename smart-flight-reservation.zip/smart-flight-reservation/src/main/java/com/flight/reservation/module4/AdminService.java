package com.flight.reservation.module4;

import com.flight.reservation.module1.PassengerService;
import com.flight.reservation.module2.FlightService;
import com.flight.reservation.module3.Reservation;
import com.flight.reservation.module3.ReservationRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class AdminService {

    private final ReservationRepository reservationRepo;
    private final AuditLogRepository    auditRepo;
    private final PassengerService      passengerService;
    private final FlightService         flightService;

    public AdminService(ReservationRepository reservationRepo,
                        AuditLogRepository auditRepo,
                        PassengerService passengerService,
                        FlightService flightService) {
        this.reservationRepo = reservationRepo;
        this.auditRepo       = auditRepo;
        this.passengerService = passengerService;
        this.flightService   = flightService;
    }

    public RevenueReport generateReport() {
        List<Reservation> all = reservationRepo.findAll();

        long confirmed  = all.stream().filter(r -> r.getResStatus() == Reservation.ResStatus.CONFIRMED).count();
        long cancelled  = all.stream().filter(r -> r.getResStatus() == Reservation.ResStatus.CANCELLED).count();
        double revenue  = all.stream()
                .filter(r -> r.getResStatus() == Reservation.ResStatus.CONFIRMED)
                .mapToDouble(r -> r.getAmountPaid() != null ? r.getAmountPaid() : 0)
                .sum();
        double avgFare  = confirmed > 0 ? revenue / confirmed : 0;

        RevenueReport report = new RevenueReport();
        report.setTotalReservations(all.size());
        report.setConfirmedReservations((int) confirmed);
        report.setCancelledReservations((int) cancelled);
        report.setTotalRevenue(Math.round(revenue * 100.0) / 100.0);
        report.setAverageFare(Math.round(avgFare * 100.0) / 100.0);
        report.setTotalFlights(flightService.listAllFlights().size());
        report.setTotalPassengers(passengerService.listAll().size());
        return report;
    }

    public void logEvent(String eventType, Integer entityId, String message) {
        auditRepo.save(new AuditLog(eventType, entityId, message));
    }

    public List<AuditLog> getAllLogs() {
        return auditRepo.findAll();
    }

    public List<AuditLog> getLogsByType(String type) {
        return auditRepo.findByEventTypeOrderByLoggedAtDesc(type);
    }
}