package com.flight.reservation.module5;

import jakarta.persistence.*;

@Entity
@Table(name = "ANCILLARY_SERVICES")
public class AncillaryService {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ancillary_id")
    private Integer ancillaryId;

    @Column(name = "reservation_id", nullable = false)
    private Integer reservationId;

    @Column(name = "service_type")
    private String serviceType;

    @Column(name = "description")
    private String description;

    @Column(name = "price")
    private Double price;

    @Column(name = "status")
    private String status = "REQUESTED";

    public AncillaryService() {}

    public Integer getAncillaryId()    { return ancillaryId; }
    public Integer getReservationId()  { return reservationId; }
    public String  getServiceType()    { return serviceType; }
    public String  getDescription()    { return description; }
    public Double  getPrice()          { return price; }
    public String  getStatus()         { return status; }

    public void setReservationId(Integer v) { this.reservationId = v; }
    public void setServiceType(String v)    { this.serviceType   = v; }
    public void setDescription(String v)    { this.description   = v; }
    public void setPrice(Double v)          { this.price         = v; }
    public void setStatus(String v)         { this.status        = v; }
}