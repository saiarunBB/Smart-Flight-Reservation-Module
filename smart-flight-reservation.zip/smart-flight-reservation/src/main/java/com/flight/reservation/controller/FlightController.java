package com.flight.reservation.controller;

import com.flight.reservation.module2.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/flights")
public class FlightController {

    private final FlightService service;

    public FlightController(FlightService service) { this.service = service; }

    @GetMapping
    public List<Flight> listAll() { return service.listAllFlights(); }

    @GetMapping("/search")
    public ResponseEntity<?> search(@RequestParam String origin,
                                     @RequestParam String destination) {
        List<Flight> results = service.searchFlights(origin, destination);
        if (results.isEmpty())
            return ResponseEntity.ok(Map.of("message", "No flights found", "flights", results));
        return ResponseEntity.ok(results);
    }

    @GetMapping("/{flightId}/seats")
    public List<Seat> availableSeats(@PathVariable int flightId) {
        return service.getAvailableSeats(flightId);
    }

    @GetMapping("/{flightId}/seats/all")
    public List<Seat> allSeats(@PathVariable int flightId) {
        return service.getAllSeats(flightId);
    }

    @GetMapping("/{flightId}/load")
    public ResponseEntity<?> loadFactor(@PathVariable int flightId) {
        int total  = service.totalSeats(flightId);
        int booked = service.bookedSeats(flightId);
        return ResponseEntity.ok(Map.of(
                "flightId", flightId, "total", total,
                "booked", booked, "available", total - booked));
    }
}