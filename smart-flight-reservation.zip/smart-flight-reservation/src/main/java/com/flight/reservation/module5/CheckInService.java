package com.flight.reservation.module5;

import com.flight.reservation.module3.Reservation;
import com.flight.reservation.module3.ReservationRepository;
import com.flight.reservation.module2.Seat;
import com.flight.reservation.module2.SeatRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class CheckInService {

    private final CheckInRepository     checkInRepo;
    private final BoardingPassRepository boardingRepo;
    private final AncillaryRepository   ancillaryRepo;
    private final ReservationRepository  reservationRepo;
    private final SeatRepository         seatRepo;

    public CheckInService(CheckInRepository checkInRepo,
                          BoardingPassRepository boardingRepo,
                          AncillaryRepository ancillaryRepo,
                          ReservationRepository reservationRepo,
                          SeatRepository seatRepo) {
        this.checkInRepo     = checkInRepo;
        this.boardingRepo    = boardingRepo;
        this.ancillaryRepo   = ancillaryRepo;
        this.reservationRepo = reservationRepo;
        this.seatRepo        = seatRepo;
    }

    @Transactional
    public CheckIn performCheckIn(int reservationId) {
        if (checkInRepo.existsByReservationId(reservationId))
            throw new IllegalStateException("Already checked in for reservation: " + reservationId);

        Reservation res = reservationRepo.findById(reservationId)
                .orElseThrow(() -> new IllegalArgumentException("Reservation not found"));

        if (res.getResStatus() != Reservation.ResStatus.CONFIRMED)
            throw new IllegalStateException("Only CONFIRMED reservations can check in.");

        String seatCode = "N/A";
        if (res.getSeatId() != null) {
            seatCode = seatRepo.findById(res.getSeatId())
                    .map(Seat::getSeatCode).orElse("N/A");
        }

        CheckIn checkIn = new CheckIn();
        checkIn.setReservationId(reservationId);
        checkIn.setSeatConfirmed(seatCode);
        return checkInRepo.save(checkIn);
    }

    @Transactional
    public BoardingPass issueBoardingPass(int reservationId) {
        if (!checkInRepo.existsByReservationId(reservationId))
            throw new IllegalStateException("Check-in required before boarding pass.");

        if (boardingRepo.findByReservationId(reservationId).isPresent())
            throw new IllegalStateException("Boarding pass already issued.");

        Reservation res = reservationRepo.findById(reservationId)
                .orElseThrow(() -> new IllegalArgumentException("Reservation not found"));

        String group = "C";
        if (res.getSeatId() != null) {
            Seat s = seatRepo.findById(res.getSeatId()).orElse(null);
            if (s != null) {
                group = switch (s.getSeatClass()) {
                    case FIRST    -> "A";
                    case BUSINESS -> "B";
                    default       -> "C";
                };
            }
        }

        BoardingPass bp = new BoardingPass();
        bp.setReservationId(reservationId);
        bp.setBoardingGroup(group);
        bp.setGate("G" + (10 + reservationId % 20));
        return boardingRepo.save(bp);
    }

    public AncillaryService addAncillary(int reservationId, String type,
                                          String description, double price) {
        reservationRepo.findById(reservationId)
                .orElseThrow(() -> new IllegalArgumentException("Reservation not found"));
        AncillaryService svc = new AncillaryService();
        svc.setReservationId(reservationId);
        svc.setServiceType(type);
        svc.setDescription(description);
        svc.setPrice(price);
        return ancillaryRepo.save(svc);
    }

    public List<AncillaryService> getAncillaries(int reservationId) {
        return ancillaryRepo.findByReservationId(reservationId);
    }

    public List<CheckIn> allCheckIns() {
        return checkInRepo.findAll();
    }

    public List<BoardingPass> allBoardingPasses() {
        return boardingRepo.findAll();
    }
}