# Smart Flight Reservation & Management System

Java 17 · Spring Boot 3.2 · H2 in-memory DB · Plain HTML/CSS/JS frontend

## Prerequisites

| Tool | Minimum version |
|------|----------------|
| JDK  | 17             |
| Maven | 3.8+          |

No database installation needed — H2 runs in-memory automatically.

## Folder structure (create exactly this)

```
smart-flight-reservation/
├── pom.xml
├── README.md
├── schema.sql                   ← copy to src/main/resources/
├── data.sql                     ← copy to src/main/resources/
└── src/
    ├── main/
    │   ├── java/com/flight/reservation/
    │   │   ├── SmartFlightApp.java
    │   │   ├── module1/   (Passenger, AuthService, PassengerService, PassengerRepository, FrequentFlyerTier)
    │   │   ├── module2/   (Flight, Seat, FlightRepository, SeatRepository, FlightService)
    │   │   ├── module3/   (Reservation, Payment, ReservationRepository, PaymentRepository, PNRGenerator, TransactionService)
    │   │   ├── module4/   (AuditLog, AuditLogRepository, RevenueReport, AdminService)
    │   │   ├── module5/   (CheckIn, BoardingPass, AncillaryService, CheckInRepository, BoardingPassRepository, AncillaryRepository, CheckInService)
    │   │   ├── controller/ (PassengerController, FlightController, ReservationController, AdminController, CheckInController)
    │   │   └── config/    (WebConfig — optional, included in source)
    │   └── resources/
    │       ├── application.properties
    │       ├── schema.sql
    │       ├── data.sql
    │       └── static/
    │           ├── index.html
    │           ├── app.css
    │           └── app.js
    └── test/
        └── java/com/flight/reservation/
            └── FlightReservationTests.java
```

## Build & run

Open VS Code's integrated terminal, `cd` into the project root, then:

```bash
mvn spring-boot:run
```

That single command downloads dependencies, compiles all sources, runs the
SQL init scripts, and starts the server.

## Accessing the application

| URL | What it is |
|-----|-----------|
| http://localhost:8080 | Web UI (all 5 modules) |
| http://localhost:8080/h2-console | H2 DB browser (JDBC URL: `jdbc:h2:mem:flightdb`) |

## Quick workflow to test all 5 modules

1. **Module 1** — Register a new passenger → Login → see all passengers
2. **Module 2** — Search flights (e.g. `Chennai` → `Mumbai`) → get seat list for flight 1
3. **Module 3** — Book seat (Passenger ID from step 1, Seat ID from step 2) → copy PNR → look it up
4. **Module 4** — Generate revenue report → view audit logs
5. **Module 5** — Check in using reservation ID from step 3 → issue boarding pass → add ancillary (e.g. BAGGAGE)

## REST API reference

### Module 1 — Passengers
```
POST /api/passengers/register   { fullName, email, phone, password }
POST /api/passengers/login       { email, password }
GET  /api/passengers
GET  /api/passengers/{id}
PUT  /api/passengers/{email}/tier?tier=GOLD
```

### Module 2 — Flights & Seats
```
GET /api/flights
GET /api/flights/search?origin=Chennai&destination=Mumbai
GET /api/flights/{id}/seats
GET /api/flights/{id}/seats/all
GET /api/flights/{id}/load
```

### Module 3 — Reservations & PNR
```
POST /api/reservations/book    { passengerId, seatId }
GET  /api/reservations
GET  /api/reservations/pnr/{PNR}
GET  /api/reservations/passenger/{pid}
PUT  /api/reservations/{id}/cancel
GET  /api/reservations/payments
```

### Module 4 — Admin
```
GET  /api/admin/report
GET  /api/admin/logs
GET  /api/admin/logs/{type}
POST /api/admin/log            { eventType, entityId, message }
```

### Module 5 — Check-In & Boarding
```
POST /api/checkin/{reservationId}
POST /api/checkin/{reservationId}/boarding-pass
POST /api/checkin/{reservationId}/ancillary  { serviceType, description, price }
GET  /api/checkin/{reservationId}/ancillary
GET  /api/checkin/all
GET  /api/checkin/boarding-passes
```